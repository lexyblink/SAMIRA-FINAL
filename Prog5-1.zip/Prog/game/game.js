//a function to implement the game (the function called when the button is clicked)
function pushDies() {	  
  //Set possible numbers between 1 and 6
  var start_number = 1;
  var end_number = 6;
  
  //Generate 2 random #s using Math.random()
  die1_value = Math.floor(Math.random() * end_number) + start_number;  
  die2_value = Math.floor(Math.random() * end_number) + start_number;

  //Output generated numbers
  var die1 = document.getElementById("1");
  var die2 = document.getElementById("2");
  die1.innerHTML = die1_value;
  die2.innerHTML = die2_value;
  
  //Calculate the sum/output
  var sum = (die1_value + die2_value);
  
  //Outputs results
  outputResults(sum);
}


//function that takes a parameter and uses this input value and outputs results.
function outputResults(sum) {
  var output = document.getElementById("result");
  var sum_output = document.getElementById("sum");
  
  //Calculate the sum/output
  sum_output.innerHTML = "SUM is "+sum;
  
  var die1 = document.getElementById("1");
  var die2 = document.getElementById("2");
  
  //If sum = 7 or sum = 11, output CRAPS – you lose!  
  if(sum == 7 || sum == 11){
	  output.innerHTML = "CRAPS – you lose!";
  //Else if die1 = die2 and die1 % 2 = 0
  }else if((die1.innerHTML == die2.innerHTML) && (die1.innerHTML % 2 == 0)){
	  output.innerHTML = "You won!";
  }else{
	  output.innerHTML = "You pushed!";
  }
}